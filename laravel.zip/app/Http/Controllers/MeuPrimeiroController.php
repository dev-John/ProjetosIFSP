<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class MeuPrimeiroController extends Controller
{
    
    public function meuController(){
        echo "Testando meu controller";
    }

}
