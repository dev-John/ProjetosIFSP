package com.ifsp.jogodado;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void sortear(View view){
        TextView txtResultado = (TextView) findViewById(R.id.txtResultado);
        TextView txtFeedback = (TextView) findViewById(R.id.txtFeedback);
        EditText edtNum = (EditText) findViewById(R.id.edtNum);
        ImageView img1 = (ImageView) findViewById(R.id.imgView1);
        ImageView img2 = (ImageView) findViewById(R.id.imgView2);

        Random random = new Random();
        int numSorteado1 = random.nextInt(6) + 1;
        int numSorteado2 = random.nextInt(6) + 1;

        switch (numSorteado1) {
            case 1:
                img1.setImageResource(R.drawable.dado1);
                break;
            case 2:
                img1.setImageResource(R.drawable.dado2);
                break;
            case 3:
                img1.setImageResource(R.drawable.dado3);
                break;
            case 4:
                img1.setImageResource(R.drawable.dado4);
                break;
            case 5:
                img1.setImageResource(R.drawable.dado5);
                break;
        }

        switch (numSorteado2) {
            case 1:
                img2.setImageResource(R.drawable.dado1);
                break;
            case 2:
                img2.setImageResource(R.drawable.dado2);
                break;
            case 3:
                img2.setImageResource(R.drawable.dado3);
                break;
            case 4:
                img2.setImageResource(R.drawable.dado4);
                break;
            case 5:
                img2.setImageResource(R.drawable.dado5);
                break;
        }

        int res = numSorteado1 + numSorteado2;

        txtResultado.setText(Integer.toString(res));

        if(!edtNum.getText().toString().equals("")){
            if(res == Integer.parseInt(edtNum.getText().toString())){
                txtFeedback.setText("Você acertou!");
            }else{
                txtFeedback.setText("Você errou...");
            }
        }

    }
}
